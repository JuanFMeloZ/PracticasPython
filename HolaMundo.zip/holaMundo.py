holaMundo = "Hola Mundo"

print(holaMundo)